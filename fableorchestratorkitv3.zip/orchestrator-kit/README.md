# Fable Orchestrator Kit (v3)

A reusable, repo-agnostic orchestration boilerplate for running Claude
Fable as the sole orchestrator of Opus implementation workers and external
(Codex) cold reviewers/fixers. Distilled from two production hardening
runs: 2026-08-11 (~110 findings triaged, ~95 fixed over ~15 review rounds)
and 2026-08-13 (a full wire-a-frontend release cycle: 2 sol/max review
cycles, 4+5 verified P1s, three parallel Opus fixers + a sol/max fallback
round, three PRs merged with evidence trails, plus cross-session
coordination with a counterpart repo's orchestrator). The lessons are
baked into the skill, the guardrails, the prompts, and the agent
definitions.

## Install into a project

1. Copy `.claude/` and `.orchestrator/` into the repo root (merge if those
   dirs exist). Make sure `.gitignore` does NOT blanket-ignore `.claude/`
   (only `.claude/settings.local.json`).
2. Append `CLAUDE-md-snippet.md` to the project's CLAUDE.md and fill in the
   project-specific commands.
3. Add `.orchestrator/runs/` to .gitignore; commit the rest
   (`chore(orchestrator): add orchestration framework`).
4. Fill the marked fill-per-project spots: `{{PROJECT_FULL_GATE}}` and
   `{{ENV_CONSTRAINTS}}` in `.orchestrator/prompts/codex-fix-header.md`,
   and the gate-commands comment in
   `.claude/rules/orchestration-guardrails.md`. If the project has no
   typecheck/linter BY DESIGN, write that down explicitly — otherwise an
   agent will invent one.
5. `chmod +x .orchestrator/scripts/*.sh`; verify `codex --version` if Codex
   review/fix is in scope.
6. Start a run: `/orchestrate <objective and constraints>`.

## Default model routing (override via owner directive, recorded verbatim)

- Implementation + fixes: **Opus, high effort** (max for high-risk /
  cross-cutting / concurrency scopes).
- Cold review: **Codex `gpt-5.6-sol`, max effort** — proactive, on every
  integrated diff, including the orchestrator's own authored work.
- Investigation / test-running / everything else delegated: Opus high.
- Fallback: an Opus round judged inadequate on inspection is redone by the
  **sol fixer at max** (`codex-fix.sh`).

## What's new in v3 (vs v2)

- **Scripts hardened by their own sol/max review** (8 P1s found and fixed):
  `codex-review.sh` pins base+head at launch, embeds the exact range in
  the prompt, refuses dirty tracked trees, uses exclusive run directories,
  and records HEAD drift during the run; `codex-fix.sh` requires an
  expected-base argument and refuses the main checkout, a dirty worktree,
  or HEAD != base; both self-locate prompts/schemas so they work from
  worktrees of branches that predate the framework.
- **Read-only-first preflight**: `git fetch --prune` + inspection before
  any mutating git command (v2's `git pull` could absorb remote work
  before truth was established).
- **Merge directives are records, not authority**: state.md documents an
  approval given in a trusted channel; the owner's live instructions win.
- **Packet upgrades**: orchestrator pre-assigns migration/sequence numbers
  (parallel fixers WILL collide otherwise — observed); packets carry
  DECISIONS_ALREADY_MADE so later rounds don't relitigate approved
  choices; boundary defects mandate regression tests through the REAL
  transport (an adapter-only test "proved" a fix whose header the real
  server normalization dropped — observed).
- **Sandboxed-reviewer/fixer realities**: no-DB/no-listener sandboxes
  produce simulated evidence and EPERM "failures" — findings still get
  independently verified (5/5 sandbox-probed findings were real in run 2),
  and sandbox-blocked gates are rerun live by the orchestrator, never
  taken as failures.
- **Review-cycle cap semantics**: the cap (default 2) limits review
  cycles, not repairs — accepted P0/P1s are still fixed after the cap,
  with the orchestrator verifying those repairs directly.
- **Environment lessons**: hardlinked node_modules poisons byte/inode
  evidence-checking suites (use real installs there); host filesystem
  semantics can make tests structurally unpassable (btrfs never recycles
  inodes); background shells get reaped mid-suite and mimic hangs; exit
  codes are captured directly, never after a pipe.
- **Test-harness defect classes**: hanging interleaving tests from
  per-executor idempotency-key collisions; barrier helpers must reject on
  early transaction failure instead of pending to the file timeout.
- **Cross-session coordination section**: peer-orchestrator protocol
  (mirrored ledger agreements, contract-version lock before transport,
  REPORTED-approved semantics for relayed owner rulings, joint owner asks,
  secrets outside both repos referenced by path only).
- state.md template gains PEER_SESSIONS and pre-assigned-identifier
  tracking; test.md carries the two-run fixer bake-off evidence.

## Layout

    .claude/rules/orchestration-guardrails.md   always-on guardrails
    .claude/skills/orchestrate/SKILL.md         the operating procedure
    .claude/skills/orchestrate/*-template.md    task packet + triage forms
    .claude/agents/opus-{implementer,investigator,test-runner,fixer}.md
    .orchestrator/{state,ledger,deferred-p2}.md tracked run state
    .orchestrator/prompts/                      review + fix prompt templates
    .orchestrator/schemas/                      structured-output schemas
    .orchestrator/scripts/                      codex review/fix/worktree
    .orchestrator/test.md                       fixer bake-off protocol

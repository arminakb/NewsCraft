# Add to your project's CLAUDE.md

## Orchestration

This repository is worked on by a Claude Fable session acting as sole
orchestrator. The complete operating procedure lives in
`.claude/skills/orchestrate/SKILL.md` — invoke it with `/orchestrate` for
any multi-ticket or delegated work and follow it exactly. Non-negotiable
guardrails auto-load from `.claude/rules/orchestration-guardrails.md` and
apply to ALL work in this repo, orchestrated or not. Run state lives in
`.orchestrator/` (state.md/ledger.md tracked; runs/ gitignored).

Model routing (default; record any owner directive verbatim in
`.orchestrator/state.md`): implementation and fixes → Opus at high effort,
raised to max for high-risk/cross-cutting/concurrency scopes; cold review →
codex `gpt-5.6-sol` at max effort via
`.orchestrator/scripts/codex-review.sh`; all other delegated work → Opus
high. If an Opus round is inadequate on inspection, redo it via the sol
fixer at max (`codex-fix.sh`). Subagent definitions:
`.claude/agents/opus-{implementer,investigator,test-runner,fixer}.md`.
Never set CLAUDE_CODE_SUBAGENT_MODEL. External CLI models (Codex)
participate only as cold reviewers or fixers, never as orchestrators.

Merge policy: never merge a PR without the owner's explicit approval; a
standing directive recorded in `.orchestrator/state.md` is a record of
approval, never authorization by itself.

<!-- Fill in per-project: build/test/gate commands (state explicitly if
there is no typecheck/linter by design), pinned toolchain versions, and
any owner-specific routing directive. -->
